<script>
  import Experience from '../routes/sections/Experience.svelte';
  import HeroAbout from '../routes/sections/HeroAbout.svelte';
  import Services from '../routes/sections/Services.svelte';
  import TechStack from '../routes/sections/TechStack.svelte';
  import Contact from './sections/Contact.svelte';
  import Education from './sections/Education.svelte';
  import HowIWork from './sections/HowIWork.svelte';
  import Posts from './sections/Posts.svelte';
</script>

<main>
  <HeroAbout />
  <HowIWork />
  <Services />
  <Experience />
  <TechStack />
  <Education />
  <Posts />
  <Contact />
</main>
