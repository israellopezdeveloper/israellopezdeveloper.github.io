# src/editor/services/__init__.py
from .io import load_json, save_json, validate, defaults
from .summarize import summarize_html
