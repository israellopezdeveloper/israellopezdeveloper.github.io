# src/editor/models/__init__.py
from .schema import (
    Link,
    PeriodTime,
    Project,
    Work,
    UniversityEntry,
    ComplementaryEntry,
    Acreditation,
    LanguageEntry,
    Educations,
    Profile,
    PortfolioData,
)
